# Asset Scanner Android App

تطبيق أندرويد للبحث السريع عن الأصول الثابتة من خلال تصوير ملصق الأصل (OCR) أو البحث اليدوي في ملف Excel (.xlsx).

## المميزات
- قراءة رقم الأصل مباشرة عبر الكاميرا أو من صورة في الاستوديو باستخدام **Google ML Kit**.
- اختيار وتحديث ملف الإكسل (`.xlsx`) في أي وقت وحفظه للعمل بدون إنترنت.
- استخراج وعرض بطاقة بيانات متكاملة تشمل:
  - `Main No.`
  - `Sub#`
  - `Asset Description`
  - `A.Class`
  - `Cost Center`
  - `Location`
  - `Room`
  - `Inventory Number`
  - `Last Inv.`
