package com.pg.assetscanner

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.pg.assetscanner.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val pickExcelLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            lifecycleScope.launch(Dispatchers.IO) {
                val saved = ExcelHelper.saveExcelFile(this@MainActivity, it)
                withContext(Dispatchers.Main) {
                    if (saved) {
                        updateFileStatus()
                        Toast.makeText(this@MainActivity, "تم حفظ وتفعيل ملف الإكسل بنجاح", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@MainActivity, "فشل تحميل الملف، تأكد أنه بصيغة .xlsx", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private val requestCameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            takePictureLauncher.launch(null)
        } else {
            Toast.makeText(this, "يجب منح صلاحية الكاميرا للتصوير", Toast.LENGTH_SHORT).show()
        }
    }

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        bitmap?.let {
            val image = InputImage.fromBitmap(it, 0)
            processImageForAssetNumber(image)
        }
    }

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val image = InputImage.fromFilePath(this, it)
                processImageForAssetNumber(image)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر فتح الصورة", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        updateFileStatus()

        binding.btnSelectExcel.setOnClickListener {
            pickExcelLauncher.launch(arrayOf(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel"
            ))
        }

        binding.btnSearch.setOnClickListener {
            val query = binding.etSearchQuery.text.toString()
            if (query.isNotBlank()) performSearch(query)
        }

        binding.btnCamera.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                takePictureLauncher.launch(null)
            } else {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }

        binding.btnGallery.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
    }

    private fun updateFileStatus() {
        val savedName = ExcelHelper.getSavedFileName(this)
        if (savedName != null) {
            binding.tvFileStatus.text = "الملف النشط: $savedName ✓"
        } else {
            binding.tvFileStatus.text = "حالة الملف: يرجى اختيار ملف الإكسل للبدء"
        }
    }

    private fun processImageForAssetNumber(image: InputImage) {
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                val rawText = visionText.text
                val regex = Regex("""\b\d{10,15}(-\d+)?\b""")
                val match = regex.find(rawText)

                if (match != null) {
                    val extractedNumber = match.value
                    binding.etSearchQuery.setText(extractedNumber)
                    performSearch(extractedNumber)
                } else {
                    Toast.makeText(this, "لم يتم العثور على رقم أصل واضح في الصورة", Toast.LENGTH_LONG).show()
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "حدث خطأ أثناء قراءة الصورة", Toast.LENGTH_SHORT).show()
            }
    }

    private fun performSearch(query: String) {
        if (!ExcelHelper.hasSavedFile(this)) {
            Toast.makeText(this, "يرجى اختيار ملف الإكسل أولاً!", Toast.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            val asset = ExcelHelper.searchAsset(this@MainActivity, query)
            withContext(Dispatchers.Main) {
                if (asset != null) {
                    binding.cardResult.visibility = View.VISIBLE
                    binding.tvBadgeInv.text = asset.inventoryNumber
                    val formattedHtml = """
                        <b>Main No.:</b> ${asset.mainNo}<br/>
                        <b>Sub#:</b> ${asset.subNo}<br/>
                        <b>Asset Description:</b> ${asset.description}<br/>
                        <b>A.Class:</b> ${asset.assetClass}<br/>
                        <b>Cost Center:</b> ${asset.costCenter}<br/>
                        <b>Location:</b> ${asset.location}<br/>
                        <b>Room:</b> ${asset.room}<br/>
                        <b>Inventory Number:</b> ${asset.inventoryNumber}<br/>
                        <b>Last Inv.:</b> ${asset.lastInv}
                    """.trimIndent()
                    binding.tvAssetDetails.text = Html.fromHtml(formattedHtml, Html.FROM_HTML_MODE_COMPACT)
                } else {
                    binding.cardResult.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "الأصل ($query) غير موجود في الشيت", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
