package com.assetsmart.app

import android.os.Bundle
import android.net.wifi.WifiManager
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.assetsmart.app.data.AssetDatabase
import com.assetsmart.app.data.AssetEntity
import com.assetsmart.app.server.AssetServer
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface

private val Black = Color(0xFF101010)
private val Gold = Color(0xFFD6AD45)

class MainActivity : ComponentActivity() {
    private var server: AssetServer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AssetDatabase.get(this)
        setContent { AssetSmartScreen(db, onServerToggle = { enabled ->
            if (enabled) {
                if (server == null) server = AssetServer(db.assetDao()).also { it.start() }
            } else {
                server?.stop(); server = null
            }
        }) }
    }
    override fun onDestroy() { server?.stop(); server = null; super.onDestroy() }
}

@Composable
private fun AssetSmartScreen(db: AssetDatabase, onServerToggle: (Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    var serverOn by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(emptyList<AssetEntity>()) }
    var assetNo by remember { mutableStateOf("") }
    var subNo by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("جاهز للاستخدام") }
    val count by produceState(initialValue = 0) { value = db.assetDao().count() }
    val ip = remember { localIpAddress() }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Color(0xFF202020))) {
        Column(Modifier.fillMaxSize().background(Black).padding(18.dp)) {
            Text("ASSET SMART", color = Gold, fontSize = 25.sp)
            Text("إدارة الأصول والعهد", color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF242424)), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("السيرفر المركزي", color = Gold, fontSize = 18.sp)
                    Text(if (serverOn) "يعمل على $ip:8080" else "متوقف", color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        serverOn = !serverOn
                        onServerToggle(serverOn)
                        message = if (serverOn) "تم تشغيل السيرفر المحلي" else "تم إيقاف السيرفر"
                    }) { Text(if (serverOn) "إيقاف السيرفر" else "تشغيل السيرفر") }
                    Text("يجب أن تكون الهواتف على شبكة Wi-Fi نفسها.", color = Color.LightGray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("عدد الأصول: $count", color = Gold)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("بحث برقم الأصل أو الفرعي أو الوصف") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { scope.launch { results = db.assetDao().search(query.trim()) } }, modifier = Modifier.fillMaxWidth()) { Text("بحث") }
            Spacer(Modifier.height(10.dp))
            Text("إضافة أصل تجريبي / جديد", color = Gold)
            OutlinedTextField(assetNo, { assetNo = it }, label = { Text("Asset Number *") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(subNo, { subNo = it }, label = { Text("Sub Number") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(description, { description = it }, label = { Text("الوصف") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                if (assetNo.isBlank()) { message = "رقم الأصل مطلوب" }
                else scope.launch {
                    db.assetDao().upsert(AssetEntity(assetNumber = assetNo.trim(), subNumber = subNo.trim(), description = description.trim()))
                    assetNo = ""; subNo = ""; description = ""; message = "تم حفظ الأصل محلياً"
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الأصل") }
            Text(message, color = Gold, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(results) { a ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF242424))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${a.assetNumber}  /  ${a.subNumber}", color = Gold)
                            Text(a.description, color = Color.White)
                            Text("${a.department} • ${a.location} • ${a.employeeName}", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun localIpAddress(): String = try {
    NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
        .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: "تحقق من Wi-Fi"
} catch (_: Exception) { "تحقق من Wi-Fi" }
