package com.assetsmart.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import com.assetsmart.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Black = Color(0xFF101010)
private val Gold = Color(0xFFD6AD45)
private val Panel = Color(0xFF242424)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AssetDatabase.get(this)
        setContent { AssetSmartScreen(db) }
    }
}

@Composable
private fun AssetSmartScreen(db: AssetDatabase) {
    var page by remember { mutableStateOf("home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Black).padding(16.dp)) {
            Text("ASSET SMART", color = Gold, fontSize = 25.sp)
            Text("إدارة الأصول والعهد", color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("home" to "الرئيسية", "employees" to "الموظفون", "departments" to "الأقسام", "locations" to "المواقع", "transfers" to "حركة العهد").forEach { (key, label) ->
                    TextButton(onClick = { page = key }) { Text(label, color = if (page == key) Gold else Color.LightGray, fontSize = 11.sp) }
                }
            }
            when (page) {
                "employees" -> EmployeesPage(db.organizationDao())
                "departments" -> NamesPage("إدارة الأقسام", "اسم القسم", true, db.organizationDao())
                "locations" -> NamesPage("إدارة المواقع", "اسم الموقع", false, db.organizationDao())
                "transfers" -> TransfersPage(db)
                else -> HomePage(db)
            }
        }
    }
}

@Composable
private fun HomePage(db: AssetDatabase) {
    val scope = rememberCoroutineScope()
    val assets by db.assetDao().observeAll().collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(emptyList<AssetEntity>()) }
    var assetNo by remember { mutableStateOf("") }
    var subNo by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var assetType by remember { mutableStateOf("INDIVIDUAL") }
    var quantity by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("قطعة") }
    var unitPrice by remember { mutableStateOf("0") }
    var currency by remember { mutableStateOf("EGP") }
    var purchaseDate by remember { mutableStateOf("") }
    var supplier by remember { mutableStateOf("") }
    var invoice by remember { mutableStateOf("") }
    var currentValue by remember { mutableStateOf("0") }
    var depreciation by remember { mutableStateOf("0") }
    var salvageValue by remember { mutableStateOf("0") }
    var message by remember { mutableStateOf("جاهز للاستخدام") }
    val totalUnits = assets.sumOf { it.quantity }
    val purchaseTotals = assets.groupBy { it.currency }.mapValues { (_, rows) ->
        rows.sumOf { it.quantity * it.purchaseUnitPrice }
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("وضع التشغيل المحلي", color = Gold, fontSize = 18.sp)
                        Text("بياناتك محفوظة على هذا الهاتف فقط • يعمل بدون إنترنت", color = Color.White, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("عدد سجلات الأصول: ${assets.size}  |  إجمالي الوحدات: ${"%.2f".format(totalUnits)}", color = Gold)
                Text("إجمالي قيمة الشراء حسب العملة:", color = Color.White)
                purchaseTotals.forEach { (cur, total) ->
                    val currentTotal = assets.filter { it.currency == cur }.sumOf { it.currentValue }
                    Text("$cur  شراء: ${"%.2f".format(total)}  |  قيمة حالية: ${"%.2f".format(currentTotal)}", color = Gold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(query, { query = it }, label = { Text("بحث برقم الأصل أو الفرعي أو الوصف") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = { scope.launch { results = db.assetDao().search(query.trim()) } }, modifier = Modifier.fillMaxWidth()) { Text("بحث") }
                Spacer(Modifier.height(8.dp))
                Text("إضافة أصل / صنف جديد", color = Gold, fontSize = 18.sp)
                Text("نوع التسجيل", color = Color.LightGray)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = assetType == "INDIVIDUAL", onClick = { assetType = "INDIVIDUAL"; quantity = "1" }, label = { Text("أصل فردي") })
                    FilterChip(selected = assetType == "BULK", onClick = { assetType = "BULK" }, label = { Text("صنف بكميات") })
                }
                OutlinedTextField(assetNo, { assetNo = it }, label = { Text("Asset Number *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(subNo, { subNo = it }, label = { Text("Sub Number") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(description, { description = it }, label = { Text("اسم / وصف الأصل") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(quantity, { quantity = it }, label = { Text("الكمية") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(unit, { unit = it }, label = { Text("وحدة القياس") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(unitPrice, { unitPrice = it }, label = { Text("سعر الوحدة") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(currency, { currency = it.uppercase() }, label = { Text("العملة (مثال EGP / USD / SAR)") }, modifier = Modifier.fillMaxWidth())
                Text("إجمالي الشراء: ${((quantity.toDoubleOrNull() ?: 0.0) * (unitPrice.toDoubleOrNull() ?: 0.0)).let { "%.2f".format(it) }} $currency", color = Gold)
                OutlinedTextField(purchaseDate, { purchaseDate = it }, label = { Text("تاريخ الشراء (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(supplier, { supplier = it }, label = { Text("المورد") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(invoice, { invoice = it }, label = { Text("رقم الفاتورة") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(currentValue, { currentValue = it }, label = { Text("القيمة الحالية") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(depreciation, { depreciation = it }, label = { Text("الإهلاك المتراكم") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(salvageValue, { salvageValue = it }, label = { Text("القيمة التخريدية") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val qty = quantity.toDoubleOrNull()
                    val price = unitPrice.toDoubleOrNull()
                    val current = currentValue.toDoubleOrNull()
                    val dep = depreciation.toDoubleOrNull()
                    val salvage = salvageValue.toDoubleOrNull()
                    if (assetNo.isBlank()) message = "رقم الأصل مطلوب"
                    else if (qty == null || qty <= 0 || price == null || price < 0 || current == null || current < 0 || dep == null || dep < 0 || salvage == null || salvage < 0) message = "راجع الكمية والأسعار والقيم المدخلة"
                    else scope.launch {
                        try {
                            db.assetDao().upsert(AssetEntity(
                                assetNumber = assetNo.trim(), subNumber = subNo.trim(), description = description.trim(),
                                assetType = assetType, quantity = if (assetType == "INDIVIDUAL") 1.0 else qty,
                                unit = unit.trim().ifBlank { "قطعة" }, purchaseUnitPrice = price,
                                currency = currency.trim().uppercase().ifBlank { "EGP" }, purchaseDate = purchaseDate.trim(),
                                supplier = supplier.trim(), invoiceNumber = invoice.trim(), currentValue = current,
                                depreciation = dep, salvageValue = salvage
                            ))
                            assetNo=""; subNo=""; description=""; quantity="1"; unitPrice="0"; purchaseDate=""
                            supplier=""; invoice=""; currentValue="0"; depreciation="0"; salvageValue="0"
                            message = "تم حفظ بيانات الأصل المالية والكمية"
                        } catch (_: Exception) { message = "رقم الأصل مع الرقم الفرعي موجود بالفعل" }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الأصل") }
                Text(message, color = Gold, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Text("نتائج البحث / الأصول المسجلة", color = Gold, fontSize = 18.sp)
            }
            items(if (results.isEmpty()) assets else results) { a ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${a.assetNumber} / ${a.subNumber}", color = Gold)
                        Text(a.description, color = Color.White)
                        Text("الكمية: ${a.quantity} ${a.unit} • سعر الوحدة: ${a.purchaseUnitPrice} ${a.currency}", color = Color.LightGray, fontSize = 12.sp)
                        Text("إجمالي الشراء: ${a.quantity * a.purchaseUnitPrice} ${a.currency} • القيمة الحالية: ${a.currentValue} ${a.currency}", color = Color.LightGray, fontSize = 12.sp)
                        Text("المورد: ${a.supplier} • الفاتورة: ${a.invoiceNumber}", color = Color.LightGray, fontSize = 12.sp)
                        Text("${a.department} • ${a.location} • ${a.employeeName}", color = Color.LightGray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmployeesPage(dao: OrganizationDao) {
    val scope = rememberCoroutineScope()
    val employees by dao.observeEmployees().collectAsState(initial = emptyList())
    var code by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    var dept by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("إدارة الموظفين", color = Gold, fontSize = 20.sp)
        OutlinedTextField(code, { code = it }, label = { Text("كود الموظف *") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(name, { name = it }, label = { Text("اسم الموظف *") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dept, { dept = it }, label = { Text("القسم") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("الهاتف") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (code.isBlank() || name.isBlank()) msg = "كود الموظف والاسم مطلوبان" else scope.launch {
            try { dao.addEmployee(EmployeeEntity(employeeCode = code.trim(), fullName = name.trim(), department = dept.trim(), phone = phone.trim())); code=""; name=""; dept=""; phone=""; msg="تمت إضافة الموظف" }
            catch (_: Exception) { msg = "كود الموظف مستخدم بالفعل" }
        } }, modifier = Modifier.fillMaxWidth()) { Text("إضافة موظف") }
        Text(msg, color = Gold)
        LazyColumn(Modifier.weight(1f)) { items(employees) { e ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(e.fullName, color = Gold); Text("${e.employeeCode} • ${e.department} • ${e.phone}", color = Color.LightGray, fontSize = 12.sp) }
                    TextButton(onClick = { scope.launch { dao.deleteEmployee(e.id) } }) { Text("حذف", color = Color.Red) }
                }
            }
        } }
    }
}

@Composable
private fun NamesPage(title: String, hint: String, department: Boolean, dao: OrganizationDao) {
    val scope = rememberCoroutineScope()
    val departments by dao.observeDepartments().collectAsState(initial = emptyList())
    val locations by dao.observeLocations().collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    val rows = if (department) departments.map { it.id to it.name } else locations.map { it.id to it.name }
    Column(Modifier.fillMaxSize()) {
        Text(title, color = Gold, fontSize = 20.sp)
        OutlinedTextField(name, { name = it }, label = { Text("$hint *") }, modifier = Modifier.fillMaxWidth())
        if (!department) OutlinedTextField(desc, { desc = it }, label = { Text("وصف الموقع") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (name.isBlank()) msg = "الاسم مطلوب" else scope.launch {
            if (department) dao.addDepartment(DepartmentEntity(name = name.trim())) else dao.addLocation(LocationEntity(name = name.trim(), description = desc.trim()))
            name = ""; desc = ""; msg = "تم الحفظ"
        } }, modifier = Modifier.fillMaxWidth()) { Text("إضافة") }
        Text(msg, color = Gold)
        LazyColumn(Modifier.weight(1f)) { items(rows) { row ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(row.second, color = Color.White)
                    TextButton(onClick = { scope.launch { if (department) dao.deleteDepartment(row.first) else dao.deleteLocation(row.first) } }) { Text("حذف", color = Color.Red) }
                }
            }
        } }
    }
}

@Composable
private fun TransfersPage(db: AssetDatabase) {
    val scope = rememberCoroutineScope()
    val transfers by db.organizationDao().observeTransfers().collectAsState(initial = emptyList())
    var assetNumber by remember { mutableStateOf("") }; var toEmployee by remember { mutableStateOf("") }
    var toDept by remember { mutableStateOf("") }; var toLocation by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("نقل العهدة", color = Gold, fontSize = 20.sp)
        OutlinedTextField(assetNumber, { assetNumber = it }, label = { Text("Asset Number *") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(toEmployee, { toEmployee = it }, label = { Text("الموظف المستلم") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(toDept, { toDept = it }, label = { Text("القسم الجديد") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(toLocation, { toLocation = it }, label = { Text("الموقع الجديد") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (assetNumber.isBlank()) msg = "رقم الأصل مطلوب" else scope.launch {
            val asset = db.assetDao().search(assetNumber.trim()).firstOrNull { it.assetNumber.equals(assetNumber.trim(), true) }
            if (asset == null) msg = "الأصل غير موجود" else {
                db.organizationDao().addTransfer(AssetTransferEntity(assetId = asset.id, assetNumber = asset.assetNumber,
                    fromEmployee = asset.employeeName, toEmployee = toEmployee.trim(), fromDepartment = asset.department,
                    toDepartment = toDept.trim(), fromLocation = asset.location, toLocation = toLocation.trim(), notes = notes.trim()))
                db.assetDao().update(asset.copy(employeeName = toEmployee.trim(), department = toDept.trim(), location = toLocation.trim()))
                assetNumber=""; toEmployee=""; toDept=""; toLocation=""; notes=""; msg="تم تسجيل حركة العهدة وتحديث بيانات الأصل"
            }
        } }, modifier = Modifier.fillMaxWidth()) { Text("تأكيد نقل العهدة") }
        Text(msg, color = Gold, fontSize = 12.sp)
        Text("آخر الحركات", color = Gold)
        LazyColumn(Modifier.weight(1f)) { items(transfers) { t ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(10.dp)) {
                    Text("${t.assetNumber} • ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(t.transferDate))}", color = Gold)
                    Text("${t.fromEmployee} ← ${t.toEmployee}", color = Color.White)
                    Text("${t.fromDepartment} ← ${t.toDepartment} | ${t.fromLocation} ← ${t.toLocation}", color = Color.LightGray, fontSize = 12.sp)
                    if (t.notes.isNotBlank()) Text(t.notes, color = Color.LightGray, fontSize = 12.sp)
                }
            }
        } }
    }
}

