package com.assetsmart.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import com.assetsmart.app.data.*
import com.assetsmart.app.server.AssetServer
import kotlinx.coroutines.launch
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Black = Color(0xFF101010)
private val Gold = Color(0xFFD6AD45)
private val Panel = Color(0xFF242424)

class MainActivity : ComponentActivity() {
    private var server: AssetServer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AssetDatabase.get(this)
        setContent { AssetSmartScreen(db, onServerToggle = { enabled ->
            if (enabled) { if (server == null) server = AssetServer(db.assetDao()).also { it.start() } }
            else { server?.stop(); server = null }
        }) }
    }
    override fun onDestroy() { server?.stop(); server = null; super.onDestroy() }
}

@Composable
private fun AssetSmartScreen(db: AssetDatabase, onServerToggle: (Boolean) -> Unit) {
    var page by remember { mutableStateOf("home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Black).padding(16.dp)) {
            Text("ASSET SMART", color = Gold, fontSize = 25.sp)
            Text("إدارة الأصول والعهد", color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("home" to "الرئيسية", "employees" to "الموظفون", "departments" to "الأقسام", "locations" to "المواقع", "transfers" to "حركة العهد").forEach { (key, label) ->
                    TextButton(onClick = { page = key }) { Text(label, color = if (page == key) Gold else Color.LightGray, fontSize = 11.sp) }
                }
            }
            when (page) {
                "employees" -> EmployeesPage(db.organizationDao())
                "departments" -> NamesPage("إدارة الأقسام", "اسم القسم", true, db.organizationDao())
                "locations" -> NamesPage("إدارة المواقع", "اسم الموقع", false, db.organizationDao())
                "transfers" -> TransfersPage(db)
                else -> HomePage(db, onServerToggle)
            }
        }
    }
}

@Composable
private fun HomePage(db: AssetDatabase, onServerToggle: (Boolean) -> Unit) {
    val scope = rememberCoroutineScope()
    var serverOn by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf(emptyList<AssetEntity>()) }
    var assetNo by remember { mutableStateOf("") }
    var subNo by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("جاهز للاستخدام") }
    var count by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { count = db.assetDao().count() }
    val ip = remember { localIpAddress() }
    Column(Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("السيرفر المركزي", color = Gold, fontSize = 18.sp)
                Text(if (serverOn) "يعمل على $ip:8080" else "متوقف", color = Color.White)
                Button(onClick = { serverOn = !serverOn; onServerToggle(serverOn); message = if (serverOn) "تم تشغيل السيرفر المحلي" else "تم إيقاف السيرفر" }) { Text(if (serverOn) "إيقاف السيرفر" else "تشغيل السيرفر") }
                Text("يجب أن تكون الهواتف على شبكة Wi-Fi نفسها.", color = Color.LightGray, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("عدد الأصول: $count", color = Gold, fontSize = 18.sp)
        OutlinedTextField(query, { query = it }, label = { Text("بحث برقم الأصل أو الفرعي أو الوصف") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { scope.launch { results = db.assetDao().search(query.trim()) } }, modifier = Modifier.fillMaxWidth()) { Text("بحث") }
        Spacer(Modifier.height(8.dp))
        Text("إضافة أصل جديد", color = Gold, fontSize = 18.sp)
        OutlinedTextField(assetNo, { assetNo = it }, label = { Text("Asset Number *") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(subNo, { subNo = it }, label = { Text("Sub Number") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("الوصف") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (assetNo.isBlank()) message = "رقم الأصل مطلوب" else scope.launch {
            db.assetDao().upsert(AssetEntity(assetNumber = assetNo.trim(), subNumber = subNo.trim(), description = description.trim()))
            assetNo = ""; subNo = ""; description = ""; count = db.assetDao().count(); message = "تم حفظ الأصل محلياً"
        } }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الأصل") }
        Text(message, color = Gold, fontSize = 13.sp)
        LazyColumn(Modifier.weight(1f)) { items(results) { a ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("${a.assetNumber} / ${a.subNumber}", color = Gold)
                    Text(a.description, color = Color.White)
                    Text("${a.department} • ${a.location} • ${a.employeeName}", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        } }
    }
}

@Composable
private fun EmployeesPage(dao: OrganizationDao) {
    val scope = rememberCoroutineScope()
    val employees by dao.observeEmployees().collectAsState(initial = emptyList())
    var code by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    var dept by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("إدارة الموظفين", color = Gold, fontSize = 20.sp)
        OutlinedTextField(code, { code = it }, label = { Text("كود الموظف *") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(name, { name = it }, label = { Text("اسم الموظف *") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(dept, { dept = it }, label = { Text("القسم") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("الهاتف") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (code.isBlank() || name.isBlank()) msg = "كود الموظف والاسم مطلوبان" else scope.launch {
            try { dao.addEmployee(EmployeeEntity(employeeCode = code.trim(), fullName = name.trim(), department = dept.trim(), phone = phone.trim())); code=""; name=""; dept=""; phone=""; msg="تمت إضافة الموظف" }
            catch (_: Exception) { msg = "كود الموظف مستخدم بالفعل" }
        } }, modifier = Modifier.fillMaxWidth()) { Text("إضافة موظف") }
        Text(msg, color = Gold)
        LazyColumn(Modifier.weight(1f)) { items(employees) { e ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(e.fullName, color = Gold); Text("${e.employeeCode} • ${e.department} • ${e.phone}", color = Color.LightGray, fontSize = 12.sp) }
                    TextButton(onClick = { scope.launch { dao.deleteEmployee(e.id) } }) { Text("حذف", color = Color.Red) }
                }
            }
        } }
    }
}

@Composable
private fun NamesPage(title: String, hint: String, department: Boolean, dao: OrganizationDao) {
    val scope = rememberCoroutineScope()
    val departments by dao.observeDepartments().collectAsState(initial = emptyList())
    val locations by dao.observeLocations().collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    val rows = if (department) departments.map { it.id to it.name } else locations.map { it.id to it.name }
    Column(Modifier.fillMaxSize()) {
        Text(title, color = Gold, fontSize = 20.sp)
        OutlinedTextField(name, { name = it }, label = { Text("$hint *") }, modifier = Modifier.fillMaxWidth())
        if (!department) OutlinedTextField(desc, { desc = it }, label = { Text("وصف الموقع") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (name.isBlank()) msg = "الاسم مطلوب" else scope.launch {
            if (department) dao.addDepartment(DepartmentEntity(name = name.trim())) else dao.addLocation(LocationEntity(name = name.trim(), description = desc.trim()))
            name = ""; desc = ""; msg = "تم الحفظ"
        } }, modifier = Modifier.fillMaxWidth()) { Text("إضافة") }
        Text(msg, color = Gold)
        LazyColumn(Modifier.weight(1f)) { items(rows) { row ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(row.second, color = Color.White)
                    TextButton(onClick = { scope.launch { if (department) dao.deleteDepartment(row.first) else dao.deleteLocation(row.first) } }) { Text("حذف", color = Color.Red) }
                }
            }
        } }
    }
}

@Composable
private fun TransfersPage(db: AssetDatabase) {
    val scope = rememberCoroutineScope()
    val transfers by db.organizationDao().observeTransfers().collectAsState(initial = emptyList())
    var assetNumber by remember { mutableStateOf("") }; var toEmployee by remember { mutableStateOf("") }
    var toDept by remember { mutableStateOf("") }; var toLocation by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("نقل العهدة", color = Gold, fontSize = 20.sp)
        OutlinedTextField(assetNumber, { assetNumber = it }, label = { Text("Asset Number *") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(toEmployee, { toEmployee = it }, label = { Text("الموظف المستلم") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(toDept, { toDept = it }, label = { Text("القسم الجديد") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(toLocation, { toLocation = it }, label = { Text("الموقع الجديد") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (assetNumber.isBlank()) msg = "رقم الأصل مطلوب" else scope.launch {
            val asset = db.assetDao().search(assetNumber.trim()).firstOrNull { it.assetNumber.equals(assetNumber.trim(), true) }
            if (asset == null) msg = "الأصل غير موجود" else {
                db.organizationDao().addTransfer(AssetTransferEntity(assetId = asset.id, assetNumber = asset.assetNumber,
                    fromEmployee = asset.employeeName, toEmployee = toEmployee.trim(), fromDepartment = asset.department,
                    toDepartment = toDept.trim(), fromLocation = asset.location, toLocation = toLocation.trim(), notes = notes.trim()))
                db.assetDao().update(asset.copy(employeeName = toEmployee.trim(), department = toDept.trim(), location = toLocation.trim()))
                assetNumber=""; toEmployee=""; toDept=""; toLocation=""; notes=""; msg="تم تسجيل حركة العهدة وتحديث بيانات الأصل"
            }
        } }, modifier = Modifier.fillMaxWidth()) { Text("تأكيد نقل العهدة") }
        Text(msg, color = Gold, fontSize = 12.sp)
        Text("آخر الحركات", color = Gold)
        LazyColumn(Modifier.weight(1f)) { items(transfers) { t ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(10.dp)) {
                    Text("${t.assetNumber} • ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(t.transferDate))}", color = Gold)
                    Text("${t.fromEmployee} ← ${t.toEmployee}", color = Color.White)
                    Text("${t.fromDepartment} ← ${t.toDepartment} | ${t.fromLocation} ← ${t.toLocation}", color = Color.LightGray, fontSize = 12.sp)
                    if (t.notes.isNotBlank()) Text(t.notes, color = Color.LightGray, fontSize = 12.sp)
                }
            }
        } }
    }
}

private fun localIpAddress(): String = try {
    NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
        .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: "تحقق من Wi-Fi"
} catch (_: Exception) { "تحقق من Wi-Fi" }
