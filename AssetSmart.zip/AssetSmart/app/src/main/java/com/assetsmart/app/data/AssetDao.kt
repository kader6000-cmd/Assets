package com.assetsmart.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Query("SELECT * FROM assets ORDER BY assetNumber, subNumber")
    fun observeAll(): Flow<List<AssetEntity>>

    @Query("SELECT * FROM assets WHERE assetNumber LIKE '%' || :q || '%' OR subNumber LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%' ORDER BY assetNumber, subNumber LIMIT 200")
    suspend fun search(q: String): List<AssetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(asset: AssetEntity): Long

    @Query("SELECT COUNT(*) FROM assets")
    suspend fun count(): Int
}
