package com.assetsmart.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Query("SELECT * FROM assets ORDER BY assetNumber, subNumber") fun observeAll(): Flow<List<AssetEntity>>
    @Query("SELECT * FROM assets WHERE assetNumber LIKE '%' || :q || '%' OR subNumber LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%' ORDER BY assetNumber, subNumber LIMIT 200") suspend fun search(q: String): List<AssetEntity>
    @Query("SELECT * FROM assets WHERE id = :id LIMIT 1") suspend fun getById(id: Long): AssetEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(asset: AssetEntity): Long
    @Update suspend fun update(asset: AssetEntity)
    @Query("SELECT COUNT(*) FROM assets") suspend fun count(): Int
}
