package com.assetsmart.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [AssetEntity::class, EmployeeEntity::class, DepartmentEntity::class, LocationEntity::class, AssetTransferEntity::class],
    version = 3,
    exportSchema = false
)
abstract class AssetDatabase : RoomDatabase() {
    abstract fun assetDao(): AssetDao
    abstract fun organizationDao(): OrganizationDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS employees (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeCode TEXT NOT NULL, fullName TEXT NOT NULL, department TEXT NOT NULL, phone TEXT NOT NULL, active INTEGER NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_employees_employeeCode ON employees(employeeCode)")
                db.execSQL("CREATE TABLE IF NOT EXISTS departments (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_departments_name ON departments(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS locations (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_locations_name ON locations(name)")
                db.execSQL("CREATE TABLE IF NOT EXISTS asset_transfers (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, assetId INTEGER NOT NULL, assetNumber TEXT NOT NULL, fromEmployee TEXT NOT NULL, toEmployee TEXT NOT NULL, fromDepartment TEXT NOT NULL, toDepartment TEXT NOT NULL, fromLocation TEXT NOT NULL, toLocation TEXT NOT NULL, transferDate INTEGER NOT NULL, notes TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_transfers_assetId ON asset_transfers(assetId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_transfers_transferDate ON asset_transfers(transferDate)")
            }
        }
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE assets ADD COLUMN assetType TEXT NOT NULL DEFAULT 'INDIVIDUAL'")
                db.execSQL("ALTER TABLE assets ADD COLUMN quantity REAL NOT NULL DEFAULT 1.0")
                db.execSQL("ALTER TABLE assets ADD COLUMN unit TEXT NOT NULL DEFAULT 'قطعة'")
                db.execSQL("ALTER TABLE assets ADD COLUMN purchaseUnitPrice REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE assets ADD COLUMN currency TEXT NOT NULL DEFAULT 'EGP'")
                db.execSQL("ALTER TABLE assets ADD COLUMN purchaseDate TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE assets ADD COLUMN supplier TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE assets ADD COLUMN invoiceNumber TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE assets ADD COLUMN currentValue REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE assets ADD COLUMN depreciation REAL NOT NULL DEFAULT 0.0")
                db.execSQL("ALTER TABLE assets ADD COLUMN salvageValue REAL NOT NULL DEFAULT 0.0")
            }
        }
        @Volatile private var INSTANCE: AssetDatabase? = null
        fun get(context: Context): AssetDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AssetDatabase::class.java, "asset_smart.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build().also { INSTANCE = it }
        }
    }
}
