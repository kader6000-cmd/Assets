package com.assetsmart.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "assets",
    indices = [Index(value = ["assetNumber", "subNumber"], unique = true), Index(value = ["assetNumber"]), Index(value = ["subNumber"])]
)
data class AssetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val assetNumber: String,
    val subNumber: String = "",
    val description: String = "",
    val serialNumber: String = "",
    val category: String = "",
    val department: String = "",
    val location: String = "",
    val employeeName: String = "",
    val employeeId: String = "",
    val status: String = "Active",
    val remarks: String = "",
    val assetType: String = "INDIVIDUAL",
    val quantity: Double = 1.0,
    val unit: String = "قطعة",
    val purchaseUnitPrice: Double = 0.0,
    val currency: String = "EGP",
    val purchaseDate: String = "",
    val supplier: String = "",
    val invoiceNumber: String = "",
    val currentValue: Double = 0.0,
    val depreciation: Double = 0.0,
    val salvageValue: Double = 0.0
)
