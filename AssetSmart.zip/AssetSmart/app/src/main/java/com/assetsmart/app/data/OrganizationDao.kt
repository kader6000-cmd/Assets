package com.assetsmart.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OrganizationDao {
    @Query("SELECT * FROM employees ORDER BY fullName") fun observeEmployees(): Flow<List<EmployeeEntity>>
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun addEmployee(item: EmployeeEntity): Long
    @Query("DELETE FROM employees WHERE id = :id") suspend fun deleteEmployee(id: Long)

    @Query("SELECT * FROM departments ORDER BY name") fun observeDepartments(): Flow<List<DepartmentEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addDepartment(item: DepartmentEntity): Long
    @Query("DELETE FROM departments WHERE id = :id") suspend fun deleteDepartment(id: Long)

    @Query("SELECT * FROM locations ORDER BY name") fun observeLocations(): Flow<List<LocationEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addLocation(item: LocationEntity): Long
    @Query("DELETE FROM locations WHERE id = :id") suspend fun deleteLocation(id: Long)

    @Insert suspend fun addTransfer(item: AssetTransferEntity): Long
    @Query("SELECT * FROM asset_transfers ORDER BY transferDate DESC LIMIT 500") fun observeTransfers(): Flow<List<AssetTransferEntity>>
    @Query("SELECT * FROM asset_transfers WHERE assetId = :assetId ORDER BY transferDate DESC") suspend fun transfersForAsset(assetId: Long): List<AssetTransferEntity>
}
