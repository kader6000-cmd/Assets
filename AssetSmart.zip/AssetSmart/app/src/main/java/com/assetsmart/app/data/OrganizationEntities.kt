package com.assetsmart.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "employees", indices = [Index(value = ["employeeCode"], unique = true)])
data class EmployeeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeCode: String,
    val fullName: String,
    val department: String = "",
    val phone: String = "",
    val active: Boolean = true
)

@Entity(tableName = "departments", indices = [Index(value = ["name"], unique = true)])
data class DepartmentEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "locations", indices = [Index(value = ["name"], unique = true)])
data class LocationEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val description: String = "")

@Entity(tableName = "asset_transfers", indices = [Index(value = ["assetId"]), Index(value = ["transferDate"])])
data class AssetTransferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val assetId: Long,
    val assetNumber: String,
    val fromEmployee: String = "",
    val toEmployee: String = "",
    val fromDepartment: String = "",
    val toDepartment: String = "",
    val fromLocation: String = "",
    val toLocation: String = "",
    val transferDate: Long = System.currentTimeMillis(),
    val notes: String = ""
)
