package com.assetsmart.app.files

import android.content.Context
import com.assetsmart.app.data.AssetDao
import com.assetsmart.app.data.AssetEntity
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.InputStream
import java.io.OutputStream

/** Excel import is deliberately column-map driven: no company-specific header names are assumed. */
object AssetExcelManager {
    data class Preview(val headers: List<String>, val sampleRows: List<List<String>>, val totalRows: Int)

    fun preview(input: InputStream): Preview {
        WorkbookFactory.create(input).use { workbook ->
            val sheet = workbook.getSheetAt(0)
            val formatter = DataFormatter()
            val headerRow = sheet.getRow(sheet.firstRowNum)
                ?: return Preview(emptyList(), emptyList(), 0)
            val headers = (0 until headerRow.lastCellNum.coerceAtLeast(0)).map {
                formatter.formatCellValue(headerRow.getCell(it)).trim().ifBlank { "Column ${it + 1}" }
            }
            val samples = (headerRow.rowNum + 1..minOf(sheet.lastRowNum, headerRow.rowNum + 5)).mapNotNull { rowIndex ->
                val row = sheet.getRow(rowIndex) ?: return@mapNotNull null
                headers.indices.map { formatter.formatCellValue(row.getCell(it)).trim() }
            }
            return Preview(headers, samples, (sheet.lastRowNum - headerRow.rowNum).coerceAtLeast(0))
        }
    }

    /** mapping keys: assetNumber, subNumber, description, serialNumber, category, department, location, employeeName, employeeId, status, remarks, assetType, quantity, unit, purchaseUnitPrice, currency, purchaseDate, supplier, invoiceNumber, currentValue, depreciation, salvageValue */
    suspend fun import(input: InputStream, dao: AssetDao, mapping: Map<String, Int>): Int {
        var imported = 0
        WorkbookFactory.create(input).use { workbook ->
            val sheet = workbook.getSheetAt(0)
            val formatter = DataFormatter()
            for (rowIndex in (sheet.firstRowNum + 1)..sheet.lastRowNum) {
                val row = sheet.getRow(rowIndex) ?: continue
                fun value(key: String) = mapping[key]?.let { formatter.formatCellValue(row.getCell(it)).trim() }.orEmpty()
                val assetNo = value("assetNumber")
                if (assetNo.isBlank()) continue
                dao.upsert(AssetEntity(
                    assetNumber = assetNo, subNumber = value("subNumber"), description = value("description"),
                    serialNumber = value("serialNumber"), category = value("category"), department = value("department"),
                    location = value("location"), employeeName = value("employeeName"), employeeId = value("employeeId"),
                    status = value("status").ifBlank { "Active" }, remarks = value("remarks"),
                    assetType = value("assetType").ifBlank { "INDIVIDUAL" },
                    quantity = value("quantity").toDoubleOrNull() ?: 1.0,
                    unit = value("unit").ifBlank { "قطعة" },
                    purchaseUnitPrice = value("purchaseUnitPrice").toDoubleOrNull() ?: 0.0,
                    currency = value("currency").ifBlank { "EGP" },
                    purchaseDate = value("purchaseDate"), supplier = value("supplier"),
                    invoiceNumber = value("invoiceNumber"),
                    currentValue = value("currentValue").toDoubleOrNull() ?: 0.0,
                    depreciation = value("depreciation").toDoubleOrNull() ?: 0.0,
                    salvageValue = value("salvageValue").toDoubleOrNull() ?: 0.0
                ))
                imported++
            }
        }
        return imported
    }

    suspend fun exportXlsx(output: OutputStream, dao: AssetDao) {
        val assets = dao.search("")
        XSSFWorkbook().use { workbook ->
            val sheet = workbook.createSheet("Assets")
            val headers = listOf("Asset Number", "Sub Number", "Description", "Serial Number", "Category", "Department", "Location", "Employee Name", "Employee ID", "Status", "Remarks", "Asset Type", "Quantity", "Unit", "Purchase Unit Price", "Currency", "Purchase Date", "Supplier", "Invoice Number", "Current Value", "Depreciation", "Salvage Value")
            sheet.createRow(0).also { row -> headers.forEachIndexed { i, h -> row.createCell(i).setCellValue(h) } }
            assets.forEachIndexed { index, a ->
                val values = listOf(a.assetNumber, a.subNumber, a.description, a.serialNumber, a.category, a.department, a.location, a.employeeName, a.employeeId, a.status, a.remarks, a.assetType, a.quantity.toString(), a.unit,
                    a.purchaseUnitPrice.toString(), a.currency, a.purchaseDate, a.supplier, a.invoiceNumber,
                    a.currentValue.toString(), a.depreciation.toString(), a.salvageValue.toString())
                sheet.createRow(index + 1).also { row -> values.forEachIndexed { i, v -> row.createCell(i).setCellValue(v) } }
            }
            headers.indices.forEach(sheet::autoSizeColumn)
            workbook.write(output)
        }
    }
}
