package com.assetsmart.app.files

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.assetsmart.app.data.AssetDao
import java.io.OutputStream

object AssetPdfReport {
    suspend fun export(output: OutputStream, dao: AssetDao) {
        val assets = dao.search("")
        val document = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 18f; isFakeBoldText = true }
        var pageNumber = 1
        var page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
        var canvas = page.canvas
        var y = 42f
        canvas.drawText("Asset Smart - Assets Report", 32f, y, titlePaint); y += 28f
        assets.forEach { a ->
            if (y > 805f) {
                document.finishPage(page); pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber).create())
                canvas = page.canvas; y = 40f
            }
            canvas.drawText("${a.assetNumber} / ${a.subNumber} | ${a.description.take(55)}", 32f, y, paint); y += 16f
            canvas.drawText("${a.department} | ${a.location} | ${a.employeeName} | ${a.status}", 42f, y, paint); y += 16f
            canvas.drawText("Qty: ${a.quantity} ${a.unit} | Unit: ${a.purchaseUnitPrice} ${a.currency} | Total: ${a.quantity * a.purchaseUnitPrice} ${a.currency}", 42f, y, paint); y += 16f
            canvas.drawText("Current: ${a.currentValue} ${a.currency} | Depreciation: ${a.depreciation} | Supplier: ${a.supplier}", 42f, y, paint); y += 20f
        }
        document.finishPage(page)
        document.writeTo(output)
        document.close()
    }
}
