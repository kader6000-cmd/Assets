package com.assetsmart.app.security

import android.content.Context

/** Device-local role selection scaffold. Production rollout should add authenticated accounts and server-side authorization. */
object RoleManager {
    enum class Role { ADMIN, SUPERVISOR, USER, REPORTS }
    fun current(context: Context): Role = runCatching {
        Role.valueOf(context.getSharedPreferences("asset_smart_security", Context.MODE_PRIVATE)
            .getString("role", Role.ADMIN.name) ?: Role.ADMIN.name)
    }.getOrDefault(Role.USER)
    fun set(context: Context, role: Role) {
        context.getSharedPreferences("asset_smart_security", Context.MODE_PRIVATE).edit().putString("role", role.name).apply()
    }
    fun canEditAssets(role: Role) = role == Role.ADMIN || role == Role.SUPERVISOR
    fun canManageUsers(role: Role) = role == Role.ADMIN
    fun canViewReports(role: Role) = role != Role.USER
}
