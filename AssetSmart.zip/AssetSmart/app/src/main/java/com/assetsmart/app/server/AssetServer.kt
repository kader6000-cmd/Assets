package com.assetsmart.app.server

import com.assetsmart.app.data.AssetDao
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject

/** Local Wi-Fi API. Keep this server on a trusted company network only. */
class AssetServer(private val dao: AssetDao, port: Int = 8080) : NanoHTTPD("0.0.0.0", port) {
    override fun serve(session: IHTTPSession): Response = try {
        when {
            session.method == Method.GET && session.uri == "/health" ->
                newFixedLengthResponse(Response.Status.OK, "application/json", "{\"status\":\"ok\",\"service\":\"Asset Smart\"}")
            session.method == Method.GET && session.uri == "/assets" -> {
                val q = session.parameters["q"]?.firstOrNull().orEmpty()
                val rows = runBlocking { dao.search(q) }
                val json = JSONArray()
                rows.forEach { a -> json.put(JSONObject().apply {
                    put("id", a.id); put("assetNumber", a.assetNumber); put("subNumber", a.subNumber)
                    put("description", a.description); put("serialNumber", a.serialNumber)
                    put("category", a.category); put("department", a.department); put("location", a.location)
                    put("employeeName", a.employeeName); put("employeeId", a.employeeId)
                    put("status", a.status); put("remarks", a.remarks)
                }) }
                newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", json.toString())
            }
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, "application/json", "{\"error\":\"not_found\"}")
        }
    } catch (e: Exception) {
        newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "application/json", "{\"error\":\"server_error\"}")
    }
}
